/* Developed by:
 * Gonzalez Pardo Adrian
 * 3CM7 20-02
 * Last file update: 21-04-2020 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define KNRM  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KMAG  "\x1B[35m"
#define KCYN  "\x1B[36m"
#define KWHT  "\x1B[37m"
#define BRED  "\x1B[91m"
#define BGRN  "\x1B[92m"
#define BYEL  "\x1B[93m"
#define BBLU  "\x1B[94m"
#define BMAG  "\x1B[95m"
#define BCYN  "\x1B[96m"
#define BWHT  "\x1B[97m"
